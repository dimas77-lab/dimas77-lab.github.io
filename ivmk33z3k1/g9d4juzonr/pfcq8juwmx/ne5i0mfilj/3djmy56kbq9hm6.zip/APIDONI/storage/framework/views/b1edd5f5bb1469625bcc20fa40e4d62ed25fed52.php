<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
	    var html = '';
	    <?php if(Route::current()->getParameter('page_number')): ?>
	    	var url = "https://yts.ag/api/v2/list_movies.json?page=<?php echo e(Route::current()->getParameter('page_number')); ?>&limit=18";
	    <?php else: ?>
	    	var url = "https://yts.ag/api/v2/list_movies.json?limit=18";
	    <?php endif; ?>
	    
	    $.getJSON(url, function(result){
	        $.each(result.data.movies, function(index, value){
	        	html = html + "<div class='col s12 m2'>"+
		          "<div class='card'>"+
		            "<div class='card-image'>"+
		              "<img src='"+value.large_cover_image+"'>"+
		              "<span class='card-title'>"+value.title+"</span>"+
		            "</div>"+
		            "<div class='card-content'>"+
		              "<a href='"+value.torrents[0].url+"' target='_blank'>"+value.torrents[0].quality+" ("+value.torrents[0].size+")</a>"+
		            "</div>"+
		            "<div class='card-action'>"+
		              "<a href='"+value.url+"' target='_blank'>Read More</a>"+
		            "</div>"+
		          "</div>"+
		        "</div>";
	            console.log(value.title);
	        });
	        $("#listMovie").html(html);
	    });

		// $.ajax({
		//     url: 'https://sportsop-soccer-sports-open-data-v1.p.mashape.com/v1/leagues',
		//     type: 'GET',
		//     data: {},
		//     dataType: 'json',
		//     success: function(data) {
		// 		console.log(data);
		// 		$.each(data.data.leagues, function(index, value){
		// 			console.log(value);
		// 			html = html + "<option value='"+value.league_slug+"'>"+value.name+" - "+value.nation+"</option>";
		// 		});
		// 		$("#selectLeague").html(html);
		// 	    $('select').material_select();
		// 		console.log(html);
	 //        },
		//     error: function(err) { alert(err); },
		//     beforeSend: function(xhr) {
		//     	xhr.setRequestHeader("X-Mashape-Authorization", "sG1VF0TSQ3mshRbi20GvcLLjLdAsp1LkRENjsnOQEk38aPBRvJ"); // Enter here your Mashape key
		//     }
		// });
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="section no-pad-bot" id="index-banner">
    	<div class="container">
	      	<br><br>
	      	<div class="row" id="listMovie">
		        
			</div>

			<ul class="pagination">
				<?php if(Route::current()->getParameter('page_number') && Route::current()->getParameter('page_number') != '1'): ?>
					<li class="waves-effect"><a href="<?php echo e(url('/page/prev')); ?>"><i class="material-icons">chevron_left</i></a></li>
				<?php else: ?>
					<li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
				<?php endif; ?>
				<li <?php echo e(Request::is('/') || Route::current()->getParameter('page_number') == 1 ? 'class=active' : ''); ?>><a href="<?php echo e(url('/page/1')); ?>">1</a></li>
				<li <?php echo e(Route::current()->getParameter('page_number') == 2 ? 'class=active' : ''); ?>><a href="<?php echo e(url('/page/2')); ?>">2</a></li>
				<li <?php echo e(Route::current()->getParameter('page_number') == 3 ? 'class=active' : ''); ?>><a href="<?php echo e(url('/page/3')); ?>">3</a></li>
				<li <?php echo e(Route::current()->getParameter('page_number') == 4 ? 'class=active' : ''); ?>><a href="<?php echo e(url('/page/4')); ?>">4</a></li>
				<li <?php echo e(Route::current()->getParameter('page_number') == 5 ? 'class=active' : ''); ?>><a href="<?php echo e(url('/page/5')); ?>">5</a></li>
				<?php if(Route::current()->getParameter('page_number') != '5'): ?>
					<li class="waves-effect"><a href="<?php echo e(url('/page/next')); ?>"><i class="material-icons">chevron_right</i></a></li>
				<?php else: ?>
					<li class="disabled"><a href="<?php echo e(url('/page/next')); ?>"><i class="material-icons">chevron_right</i></a></li>				
				<?php endif; ?>
			</ul>
			        
    	</div>
  	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>