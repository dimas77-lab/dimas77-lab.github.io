<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
	    var html = '';

	    $.getJSON("https://yts.ag/api/v2/list_movies.json", function(result){
	        $.each(result.data.movies, function(index, value){
	        	html = html + "<div class='col s12 m3'>"+
		          "<div class='card'>"+
		            "<div class='card-image'>"+
		              "<img src='"+value.large_cover_image+"'>"+
		              "<span class='card-title'></span>"+
		            "</div>"+
		            "<div class='card-content'>"+
		              "<p>"+value.title+"</p>"+
		            "</div>"+
		            "<div class='card-action'>"+
		              "<a href='"+value.url+"' target='_blank'>Read More</a>"+
		            "</div>"+
		          "</div>"+
		        "</div>";
	            console.log(value.title);
	        });
	        $("#listMovie").html(html);
	    });

		// $.ajax({
		//     url: 'https://sportsop-soccer-sports-open-data-v1.p.mashape.com/v1/leagues',
		//     type: 'GET',
		//     data: {},
		//     dataType: 'json',
		//     success: function(data) {
		// 		console.log(data);
		// 		$.each(data.data.leagues, function(index, value){
		// 			console.log(value);
		// 			html = html + "<option value='"+value.league_slug+"'>"+value.name+" - "+value.nation+"</option>";
		// 		});
		// 		$("#selectLeague").html(html);
		// 	    $('select').material_select();
		// 		console.log(html);
	 //        },
		//     error: function(err) { alert(err); },
		//     beforeSend: function(xhr) {
		//     	xhr.setRequestHeader("X-Mashape-Authorization", "sG1VF0TSQ3mshRbi20GvcLLjLdAsp1LkRENjsnOQEk38aPBRvJ"); // Enter here your Mashape key
		//     }
		// });
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="section no-pad-bot" id="index-banner">
    	<div class="container">
	      	<br><br>
	      	<h1 class="header center orange-text">Movie List</h1>
	      	<div class="row" id="listMovie">
		        
			</div>
    	</div>
  	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>