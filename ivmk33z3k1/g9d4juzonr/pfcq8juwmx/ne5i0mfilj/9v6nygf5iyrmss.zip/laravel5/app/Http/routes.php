<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
/*Route::bind('siswa',function ($siswa)
{
return App\Siswa::find($siswa);
});
Route::resource('siswa','SiswaController');*/


Route::get('/', 'WelcomeController@index');

Route::get('home', 'HomeController@index');

Route::get('artikel', 'ArtikelController@index');

Route::get('artikel/add', 'ArtikelController@create');

Route::post('artikel/save', 'ArtikelController@store');

Route::post('artikel/update', 'ArtikelController@update');

Route::get('artikel/edit/{id}', 'ArtikelController@edit');

Route::get('/images/{filename}',
	function ($filename)
{
	$path = storage_path() . '/' .$filename;

	$file = File::get($path);
	$type = File::mimeType($path);

	$response = Response::make($file,200);
	$response->header("Content-Type", $type);

	return $response;
});

Route::get('/pdf/{slug}','WelcomeController@showpdf');

Route::get('/{slug}', 'ArtikelController@show');

Route::get('/mail/{slug}', function ($slug)
{
	$artikel = \App\Posts::where('slug',$slug)->first();

	Mail::send('artikel.pdf', ['data' => $artikel],
		function($message)
	{
		$message->to(Auth::user()->email, Auth::user()->name)
		->subject("Update Artikel");
	});

	return redirect(url());
});

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);

/*Route::get('checkpdf/{value?}', function($value='HELLO')
{
	$pdf = App::make('dompdf.wrapper');
	$pdf->loadHTML('<h1>'.$value.'</h1>');
	return $pdf->stream();
});*/