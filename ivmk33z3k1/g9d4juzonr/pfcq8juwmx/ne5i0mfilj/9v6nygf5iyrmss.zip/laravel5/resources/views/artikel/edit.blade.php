@extends('app')

@section('content')
<div class="panel">
	<div class="heading">
		<span class="title">
			<span class="class .header">Edit a Post</span>
		</span>
	</div>
	<div class="content">
		<form method="POST" action="{{ url('artikel/update') }}" enctype="multipart/form-data">
			<table style="width:100%">
				<tr>
					<td>Judul</td>
					<td>
						<div class="input-control text full-size">
								<input type="text" name="judul" value="{{ $data->judul }}"> 
								<input type="hidden" name="id" value="{{ $data->id }}"> 
								<input type="hidden" name="_token" value="{{ csrf_token() }}">
						</div>
					</td>
				</tr>
				<tr>
					<td>Isi</td>
					<td>
						<div class="input-control textarea full-size">
							<textarea name="isi">{{ $data->isi }}</textarea>
						</div>
					</td>
				</tr>
				<tr>
					<td>Tag</td>
					<td>
						<div class="input-control text full-size">
							<input type="text" name="tag" value="{{ $data->tag }}">
						</div>
					</td>
				</tr>
				<tr>
					<td>Sampul</td>
					<td>

					<img src="{{ url('images/'. $data->sampul) }}">
						<div class="input-control file full-size" data-role="input">
							<input type="file" name="sampul">
							<button class="button"><span class="mif-folder"></span></button>
						</div>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<button class="button info block-shadow-info text-shadow" type="submit">Submit</button>
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
@endsection