@extends('app')

@section('content')

	<div class="panel">
		<div class="heading">
			<div class="icon mif-file-text"></div>
			<div class="title">{{ $data->judul }}</div>
		</div>
		<div class="content">
			{{ $data->isi }}

			<div class="place-right">
				<span class="mif-calendar"></span>
				{{ date_format(date_create($data->created_at), "D, d M Y H:i:s") }}
				<span class="mif-user"></span>
				{{ App\User::find($data->idpengguna)['name'] }}
			</div>
		</div>
	</div>

	<div class="panel">
		<div class="heading">
			<div class="icon mif-bubbles"></div>
			<div class="title">Comments</div>
		</div>
		<div class="content">
			
			<div id="form">
				<span class="mif-spinner5 mif-ani-spin" style="padding:50px;font-size:25pt;"></span>
			</div>

			<div id="komentar">
				<span class="mif-spinner5 mif-ani-spin" style="padding:50px;font-size:25pt;"></span>
			</div>

		</div>
	</div>

@endsection

@section('footer')

	<script type="text/javascript">

		setTimeout(function(){

		$("#form").html(
			'<table>'+
				'<tr>'+
					'<td>'+
					'<div class="input-control textarea full-size">'+
						'<textarea id="input-komentar" type="text"></textarea>'+
					'</div>'+
					'</td>'+
				'</tr>'+
				'<tr>'+
					'<td>'+
						'<button class="button primary" onclick="send_comments()">'+
						'Submit</button>'+
					'</td>'+
				'</tr>'+
			'</table>');

	},1000);

	function send_comments () {
		$.ajax({
			url:'{{ url("komentar") }}',
			type:'POST',
			data:{'idpost':{{ $data->id }},
					'_token':'{{ csrf_token() }}',
					'isi':$("#input-komentar").val() },
			success:function (argument) {
				if(argument=="sukses"){
					alert('sukses');
				}
			},
			error:function () {
				alert('error');
			}
		});
	}

	</script>

@endsection